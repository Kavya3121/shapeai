import React from "react";

const Temp = () => {
    return <div>Hello, this is a temp!!!</div>
};


export default Temp;
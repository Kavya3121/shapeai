const PremierImages= [
    {
        src:"https://in.bmscdn.com/iedb/movies/images/mobile/thumbnail/xlarge/rrr-et00094579-27-07-2021-11-33-17.jpg",
        alt:"RRR",
        title:"RRR-The Movie",
        subtitle:"Jr.NTR"
    },
    {
        src:"https://in.bmscdn.com/iedb/movies/images/mobile/thumbnail/xlarge/aravinda-sametha-veera-raghava-et00076100-21-05-2018-12-36-19.jpg",
        alt:"Aravindha Sametha VeeraRagava",
        title:"Aravindha Sametha VeeraRagava",
        subtitle:"Jr.NTR"
    },
    {
        src:"https://in.bmscdn.com/iedb/movies/images/mobile/thumbnail/xlarge/jai-lava-kusa-et00055602-18-09-2020-07-38-55.jpg",
        alt:"Jai Lava Kusa",
        title:"Jai Lava Kusa",
        subtitle:"Jr.NTR"
    },
    {
        src:"https://in.bmscdn.com/iedb/movies/images/mobile/thumbnail/xlarge/janatha-garage-et00042076-17-04-2017-17-56-31.jpg",
        alt:"Janatha Garage",
        title:"Janatha Garage",
        subtitle:"Jr.NTR"
    },
    {
        src:"https://in.bmscdn.com/iedb/movies/images/mobile/thumbnail/xlarge/nannaku-prematho-et00035840-13-02-2018-01-57-31.jpg",
        alt:"Nannaku-Prematho",
        title:"Nannaku-Prematho",
        subtitle:"Jr.NTR"
    },
    {
        src:"https://in.bmscdn.com/iedb/movies/images/mobile/thumbnail/xlarge/temper-et00026832-11-02-2020-04-30-43.jpg",
        alt:"Temper",
        title:"Temper",
        subtitle:"Jr.NTR"
    },
    {
        src:"https://in.bmscdn.com/iedb/movies/images/extra/vertical_logo/mobile/thumbnail/xxlarge/simhadri-telugu-et00312439-07-07-2021-06-18-39.jpg",
        alt:"Simhadri",
        title:"Simhadri",
        subtitle:"Jr.NTR"
    },
    {
        src:"https://in.bmscdn.com/iedb/movies/images/mobile/thumbnail/xlarge/aadi-et00000802-23-03-2021-01-08-17.jpg",
        alt:"Aadi",
        title:"Aadi",
        subtitle:"Jr.NTR"
    },
    {
        src:"https://in.bmscdn.com/iedb/movies/images/mobile/thumbnail/xlarge/yamadonga-et00000127-24-03-2017-19-45-53.jpg",
        alt:"Yamadonga",
        title:"Yamadonga",
        subtitle:"Jr.NTR"
    },
    {
        src:"https://in.bmscdn.com/iedb/movies/images/mobile/thumbnail/xlarge/ET00022558.jpg",
        alt:"Rabhasa",
        title:"Rabhasa",
        subtitle:"Jr.NTR"
    },
    {
        src:"https://in.bmscdn.com/iedb/movies/images/mobile/thumbnail/xlarge/brindaavanam-et00005325-29-12-2016-05-36-29.jpg",
        alt:"Brindaavanam",
        title:"Brindaavanam",
        subtitle:"Jr.NTR"
    },
    {
        src:"https://in.bmscdn.com/iedb/movies/images/mobile/thumbnail/xlarge/oosaravelli-et00007926-24-03-2017-20-00-02.jpg",
        alt:"Oosaravelli",
        title:"Oosaravelli",
        subtitle:"Jr.NTR"
    },
]


export default PremierImages;
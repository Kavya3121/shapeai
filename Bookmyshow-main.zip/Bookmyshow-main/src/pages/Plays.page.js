import React from "react";

const Plays = () => {
    return(
        <>
            Hello World
        </>
    );
};


export default Plays;
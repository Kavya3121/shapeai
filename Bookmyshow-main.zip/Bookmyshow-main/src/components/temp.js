import React from "react";

function Temp() {
    return <h1>This is Temp </h1>
}


export default Temp;